import logo from './logo.svg';
import './App.css';
import React, { useEffect, useState } from 'react'
function App() {
  const [users, setUsers] = useState([])
  async function fetchData(){
    try {
      const res=await fetch('https://api.thedogapi.com/v1/breeds');
      const resp=await res.json();
      setUsers(resp);
    } catch (error) {
      console.log(error);
    }
  }
      useEffect(() => {
        fetchData();
      }, [])
      console.log(users)
  return (
    <div className="items-center justify-center text-center">
      <div>
      <h2 className='text-white font-bold text-5xl mt-8'>The Dog Api</h2>
      <p className='text-white text-2xl py-5'>This is powered by <a className='text-blue-500 active:text-orange-900' target='new' href='https://api.thedogapi.com/v1/breeds'>The Dog Api</a></p>
      <div>
        <form>
        <input className='px-3 py-2 w-11/12 bg-slate-200 text--300' placeholder='Search for dog api'/>
        </form>
      </div>
      <section className='px-10 py-10'>
       <div className='grid grid-cols-3 gap-8'>
       {users.map((dog)=>{
          return(
            <article className='bg-slate-400 px-5 pt-5'>
              <a href={dog.image.url}><img src={dog.image.url} alt={dog.name} className='rounded h-4/6 w-full' /></a>
              <div className='py-3'>
                <figcaption className='text-2xl font-bold'>{dog.name}</figcaption>
                <p>{dog.bred_for}</p>
              </div>
            </article>
          )
        })}
       </div>
      </section>
      </div>
    </div>
  );
}

export default App;
